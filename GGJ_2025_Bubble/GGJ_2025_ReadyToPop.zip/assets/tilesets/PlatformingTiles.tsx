<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="PlatformingTiles" tilewidth="8" tileheight="8" tilecount="360" columns="20">
 <image source="PlatformingTiles.png" width="160" height="144"/>
</tileset>
